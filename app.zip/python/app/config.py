import os

# Environment detection
def is_aws_environment():
    """Detect if running in AWS"""
    return os.environ.get("AWS_EXECUTION_ENV") is not None or os.environ.get("AWS_LAMBDA_FUNCTION_NAME") is not None

# Configuration
ENVIRONMENT = os.environ.get("ENVIRONMENT", "local")
# Try REGION first (for Lambda), fall back to AWS_REGION (for local development)
AWS_REGION = os.environ.get("REGION", os.environ.get("AWS_REGION", "us-east-1"))
BEDROCK_MODEL_ID = os.environ.get("BEDROCK_MODEL_ID", "us.amazon.nova-pro-v1:0")
S3_BUCKET = os.environ.get("S3_BUCKET", "menu-maestro-images")
USE_S3 = os.environ.get("USE_S3", "False").lower() == "true" or is_aws_environment()

# Paths
UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", "uploads")